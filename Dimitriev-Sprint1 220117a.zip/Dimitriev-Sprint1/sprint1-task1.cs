﻿/*
    Время посылки 16 янв 2022, 23:36:17
	ID 63940244	
    отчёт https://contest.yandex.ru/contest/22450/run-report/63940244/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

public class Solution
{
    private static TextReader reader;
    private static TextWriter writer;

    public static void Main(string[] args)
    {
        reader = new StreamReader(Console.OpenStandardInput());
        writer = new StreamWriter(Console.OpenStandardOutput());

        int n = ReadInt();
        int[] houses = ReadArray();
        int housesNr = houses.Length;

        int[] distancesFromLeft = CalcDistances(houses, housesNr, 0, housesNr - 1, +1);
        int[] distancesFromRight = CalcDistances(houses, housesNr, housesNr - 1, 0, -1);

        int[] minDistance = new int[housesNr];
        for (int i = 0; i < housesNr; i++)
        {
            minDistance[i] = Math.Min(distancesFromRight[i], distancesFromLeft[i]);
            writer.Write("{0} ", minDistance[i]);
        }

        reader.Close();
        writer.Close();
    }

    private static int[] CalcDistances(int[] houses, int housesNr, int startIndex, int stopIndex, int shift)
    {
        int[] distances = new int[housesNr];
        int lastEmptyLotDistance = int.MaxValue;
        int i = startIndex;
        while (i != stopIndex + shift)
        {
            if (houses[i] == 0)
                lastEmptyLotDistance = 0;
            else
            {
                if (lastEmptyLotDistance < int.MaxValue)
                    lastEmptyLotDistance++;
            }
            distances[i] = lastEmptyLotDistance;
            i += shift;
        }
        return distances;
    }

    private static int ReadInt()
    {
        return int.Parse(reader.ReadLine());
    }

    private static int[] ReadArray()
    {
        return reader.ReadLine()
            .Split(new char[] { ' ', '\t', }, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToArray();
    }
}